import { useState, useRef, KeyboardEvent } from "react";
import { Button } from "./ui/button";
import { Textarea } from "./ui/textarea";
import { Paperclip, Image, Mic, Send, Square } from "lucide-react";
import { cn } from "./ui/utils";

interface 输入栏Props {
  value: string;
  onChange: (value: string) => void;
  onSend: () => void;
  onStop: () => void;
  onUploadPDF: (file: File) => void;
  onUploadImage: (file: File) => void;
  onUploadAudio: (file: File) => void;
  isStreaming: boolean;
  disabled?: boolean;
}

export function 输入栏({
  value,
  onChange,
  onSend,
  onStop,
  onUploadPDF,
  onUploadImage,
  onUploadAudio,
  isStreaming,
  disabled = false
}: 输入栏Props) {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const pdfInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);  
  const audioInputRef = useRef<HTMLInputElement>(null);

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (value.trim() && !isStreaming) {
        onSend();
      }
    }
    
    // 键盘快捷键
    if (e.ctrlKey || e.metaKey) {
      switch (e.key) {
        case 'u':
        case 'U':
          e.preventDefault();
          pdfInputRef.current?.click();
          break;
        case 'i':
        case 'I':
          e.preventDefault();
          imageInputRef.current?.click();
          break;
      }
    }
  };

  const handleFileUpload = (
    inputRef: React.RefObject<HTMLInputElement>,
    acceptTypes: string,
    onUpload: (file: File) => void
  ) => {
    if (inputRef.current) {
      inputRef.current.accept = acceptTypes;
      inputRef.current.onchange = (e) => {
        const file = (e.target as HTMLInputElement).files?.[0];
        if (file) {
          onUpload(file);
        }
      };
      inputRef.current.click();
    }
  };

  return (
    <div className="h-20 bg-background border-t border-border p-4">
      <div className="flex items-end gap-3 max-w-4xl mx-auto">
        {/* 文本输入框 */}
        <div className="flex-1 relative">
          <Textarea
            ref={textareaRef}
            value={value}
            onChange={(e) => onChange(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="输入您的问题... (Enter 发送，Shift+Enter 换行)"
            className="min-h-[48px] max-h-32 resize-none pr-16"
            disabled={disabled}
          />
          
          {/* 上传按钮组 */}
          <div className="absolute right-2 bottom-2 flex items-center gap-1">
            <Button
              variant="ghost"
              size="sm"
              className="w-8 h-8 p-0 hover:bg-accent"
              onClick={() => handleFileUpload(pdfInputRef, '.pdf', onUploadPDF)}
              disabled={disabled}
              title="上传 PDF (Ctrl/Cmd+U)"
            >
              <Paperclip className="w-4 h-4" />
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              className="w-8 h-8 p-0 hover:bg-accent"
              onClick={() => handleFileUpload(imageInputRef, 'image/*', onUploadImage)}
              disabled={disabled}
              title="上传图片 (Ctrl/Cmd+I)"
            >
              <Image className="w-4 h-4" />
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              className="w-8 h-8 p-0 hover:bg-accent"
              onClick={() => handleFileUpload(audioInputRef, 'audio/*', onUploadAudio)}
              disabled={disabled}
              title="上传音频"
            >
              <Mic className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* 发送/停止按钮 */}
        <div className="flex items-center gap-2">
          {isStreaming ? (
            <Button
              onClick={onStop}
              variant="destructive"
              size="sm"
              className="w-10 h-10 p-0"
            >
              <Square className="w-4 h-4" />
            </Button>
          ) : (
            <Button
              onClick={onSend}
              disabled={!value.trim() || disabled}
              className="w-10 h-10 p-0 bg-blue-500 hover:bg-blue-600"
            >
              <Send className="w-4 h-4" />
            </Button>
          )}
        </div>
      </div>

      {/* 隐藏的文件输入 */}
      <input ref={pdfInputRef} type="file" className="hidden" />
      <input ref={imageInputRef} type="file" className="hidden" />
      <input ref={audioInputRef} type="file" className="hidden" />
    </div>
  );
}