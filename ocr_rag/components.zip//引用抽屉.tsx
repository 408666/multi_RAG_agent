import { Sheet, SheetContent, SheetHeader, SheetTitle } from "./ui/sheet";
import { Badge } from "./ui/badge";
import { ScrollArea } from "./ui/scroll-area";
import { Button } from "./ui/button";
import { X } from "lucide-react";
import { Reference } from "./消息气泡";
import { cn } from "./ui/utils";

interface 引用抽屉Props {
  isOpen: boolean;
  onClose: () => void;
  references: Reference[];
  selectedReference?: Reference;
  onReferenceSelect: (reference: Reference) => void;
}

export function 引用抽屉({ 
  isOpen, 
  onClose, 
  references, 
  selectedReference, 
  onReferenceSelect 
}: 引用抽屉Props) {
  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent 
        side="bottom" 
        className="h-[50vh] rounded-t-lg"
      >
        <SheetHeader className="flex flex-row items-center justify-between">
          <SheetTitle>引用来源</SheetTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="w-8 h-8 p-0"
          >
            <X className="w-4 h-4" />
          </Button>
        </SheetHeader>

        <div className="flex h-full mt-4 gap-4">
          {/* 左侧引用列表 */}
          <div className="w-1/2 border-r pr-4">
            <ScrollArea className="h-full">
              <div className="space-y-3">
                {references.map((ref, index) => (
                  <div
                    key={ref.id}
                    className={cn(
                      "p-3 rounded-lg border cursor-pointer transition-all hover:shadow-md",
                      selectedReference?.id === ref.id 
                        ? "border-blue-500 bg-blue-50" 
                        : "hover:border-gray-300"
                    )}
                    onClick={() => onReferenceSelect(ref)}
                  >
                    <div className="flex items-start gap-3">
                      <img
                        src={ref.thumbnail}
                        alt={`${ref.docName} 第 ${ref.pageNum} 页`}
                        className="w-12 h-16 object-cover rounded border"
                      />
                      <div className="flex-1 min-w-0">
                        <h4 className="truncate">{ref.docName}</h4>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge variant="outline" className="text-xs">
                            第 {ref.pageNum} 页
                          </Badge>
                          <Badge variant="secondary" className="text-xs">
                            {ref.blockType}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-2 mt-2">
                          <span className="text-xs text-muted-foreground">
                            相似度:
                          </span>
                          <div className="flex-1 bg-gray-200 rounded-full h-1.5">
                            <div
                              className="bg-blue-500 h-1.5 rounded-full transition-all"
                              style={{ width: `${ref.similarity * 100}%` }}
                            />
                          </div>
                          <span className="text-xs font-medium">
                            {(ref.similarity * 100).toFixed(1)}%
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </div>

          {/* 右侧预览区域 */}
          <div className="w-1/2 pl-4">
            {selectedReference ? (
              <div className="h-full flex flex-col">
                <div className="flex items-center gap-2 mb-3">
                  <h3 className="truncate">{selectedReference.docName}</h3>
                  <Badge>第 {selectedReference.pageNum} 页</Badge>
                </div>
                
                <div className="flex-1 relative bg-gray-50 rounded-lg overflow-hidden">
                  <img
                    src={selectedReference.thumbnail}
                    alt="文档预览"
                    className="w-full h-full object-contain"
                  />
                  
                  {/* 高亮矩形框 */}
                  {selectedReference.rect && (
                    <div
                      className="absolute border-2 border-red-500 bg-red-500/20 animate-pulse"
                      style={{
                        left: `${selectedReference.rect.x}%`,
                        top: `${selectedReference.rect.y}%`,
                        width: `${selectedReference.rect.width}%`,
                        height: `${selectedReference.rect.height}%`,
                      }}
                    />
                  )}
                </div>
              </div>
            ) : (
              <div className="h-full flex items-center justify-center text-muted-foreground">
                <p>点击左侧引用项查看预览</p>
              </div>
            )}
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}