import { cn } from "./ui/utils";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Badge } from "./ui/badge";
import { Bot, User, Wrench } from "lucide-react";
import { 引用上标 } from "./引用上标";

export interface ContentBlock {
  type: 'text' | 'image' | 'audio';
  content: string;
  thumbnail?: string;
  transcription?: string;
}

export interface Reference {
  id: string;
  docName: string;
  pageNum: number;
  blockType: string;
  similarity: number;
  thumbnail: string;
  rect?: { x: number; y: number; width: number; height: number };
}

export interface Message {
  id: string;
  role: 'user' | 'assistant' | 'tool';
  contentBlocks: ContentBlock[];
  references?: Reference[];
  timestamp: Date;
  isStreaming?: boolean;
}

interface 消息气泡Props {
  message: Message;
  onReferenceClick: (references: Reference[]) => void;
}

export function 消息气泡({ message, onReferenceClick }: 消息气泡Props) {
  const isUser = message.role === 'user';
  const isAssistant = message.role === 'assistant';
  const isTool = message.role === 'tool';

  const renderAvatar = () => {
    if (isUser) {
      return (
        <Avatar className="w-8 h-8">
          <AvatarFallback>
            <User className="w-4 h-4" />
          </AvatarFallback>
        </Avatar>
      );
    } else if (isAssistant) {
      return (
        <Avatar className="w-8 h-8">
          <AvatarFallback className="bg-blue-500 text-white">
            <Bot className="w-4 h-4" />
          </AvatarFallback>
        </Avatar>
      );
    } else {
      return (
        <Avatar className="w-8 h-8">
          <AvatarFallback className="bg-orange-500 text-white">
            <Wrench className="w-4 h-4" />
          </AvatarFallback>
        </Avatar>
      );
    }
  };

  const renderContent = (block: ContentBlock, index: number) => {
    switch (block.type) {
      case 'text':
        const parts = block.content.split(/(\[\d+\])/g);
        return (
          <div key={index} className="prose prose-sm max-w-none">
            {parts.map((part, i) => {
              const match = part.match(/\[(\d+)\]/);
              if (match && message.references) {
                const refIndex = parseInt(match[1]) - 1;
                const ref = message.references[refIndex];
                if (ref) {
                  return (
                    <引用上标
                      key={i}
                      number={match[1]}
                      onClick={() => onReferenceClick([ref])}
                    />
                  );
                }
              }
              return <span key={i}>{part}</span>;
            })}
          </div>
        );
      
      case 'image':
        return (
          <div key={index} className="mt-2">
            <img
              src={block.thumbnail || block.content}
              alt="上传的图片"
              className="max-w-sm rounded-lg border"
            />
          </div>
        );
      
      case 'audio':
        return (
          <div key={index} className="mt-2 p-3 bg-gray-50 rounded-lg border">
            <div className="flex items-center gap-2 mb-2">
              <Badge variant="secondary">音频</Badge>
              <span className="text-sm text-muted-foreground">已转写</span>
            </div>
            {block.transcription && (
              <p className="text-sm">{block.transcription}</p>
            )}
          </div>
        );
      
      default:
        return <div key={index}>{block.content}</div>;
    }
  };

  return (
    <div className={cn(
      "flex gap-3 mb-4",
      isUser && "flex-row-reverse"
    )}>
      {renderAvatar()}
      
      <div className={cn(
        "max-w-[70%] rounded-lg px-4 py-3 shadow-sm",
        isUser && "bg-blue-500 text-white ml-auto",
        isAssistant && "bg-white border",
        isTool && "bg-orange-50 border border-orange-200"
      )}>
        {/* 角色标识 */}
        {!isUser && (
          <div className="flex items-center gap-2 mb-2">
            <Badge variant={isAssistant ? "default" : "secondary"}>
              {isAssistant ? "助手" : "工具"}
            </Badge>
            <span className="text-xs text-muted-foreground">
              {message.timestamp.toLocaleTimeString()}
            </span>
          </div>
        )}

        {/* 内容块 */}
        <div className="space-y-2">
          {message.contentBlocks.map((block, index) => renderContent(block, index))}
        </div>

        {/* 流式输出骨架屏 */}
        {message.isStreaming && (
          <div className="flex items-center gap-1 mt-2">
            <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
            <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse" style={{ animationDelay: '0.2s' }}></div>
            <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse" style={{ animationDelay: '0.4s' }}></div>
          </div>
        )}
      </div>
    </div>
  );
}